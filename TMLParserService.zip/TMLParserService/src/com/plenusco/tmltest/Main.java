package com.plenusco.tmltest;
import com.plenusco.tml.*;

public class Main {
	public static void main (String args[]) {
		
		String tml = "<tml>" + "\r\n" +
"                    <table>" + "\r\n" +
"                        <tr>" + "\r\n" +
"                            <td></td>" + "\r\n" +
"                        </tr>" + "\r\n" +
"                        <tr>" + "\r\n" +
"                            <td align='center' width='100%'>Invoice 1</td>" + "\r\n" +
"                        </tr>" + "\r\n" +
"                        <tr>" + "\r\n" +
"                            <td></td>" + "\r\n" +
"                        </tr>" + "\r\n" +
"                        <tr>" + "\r\n" +
"                            <td mode='fill'>_</td>" + "\r\n" +
"                        </tr>" + "\r\n" +
"                    </table>" + "\r\n" +
"                    <table width='100%'>" + "\r\n" +
"                        <tr>" + "\r\n" +
"                            <td>Code </td>" + "\r\n" +
"                            <td width='*'>Description</td>" + "\r\n" +
"                            <td align='right'>Qty</td>" + "\r\n" +
"                            <td align='right'>Unit Price</td>" + "\r\n" +
"                            <td align='right'>Price</td>" + "\r\n" +
"                        </tr>" + "\r\n" +
"                        <tr>" + "\r\n" +
"                            <td  colspan='5' mode='fill'>_</td>" + "\r\n" +
"                        </tr>" + "\r\n" +
"                        <tr>" + "\r\n" +
"                            <td >A1</td>" + "\r\n" +
"                            <td mode='wrap' width='*'>AAA AAA aasdf asdf FF DDDDD     WWW FF</td>" + "\r\n" +
"                            <td align='right'>2</td>" + "\r\n" +
"                            <td align='right'>20.00</td>" + "\r\n" +
"                            <td align='right'>40.00</td>" + "\r\n" +
"                        </tr>" + "\r\n" +
"                        <tr>" + "\r\n" +
"                            <td>B1</td>" + "\r\n" +
"                            <td mode='wrap' width='*'>BB BB</td>" + "\r\n" +
"                            <td align='right'>1</td>" + "\r\n" +
"                            <td align='right'>30.00</td>" + "\r\n" +
"                            <td align='right'>30.00</td>" + "\r\n" +
"                        </tr>" + "\r\n" +
"                        <tr>" + "\r\n" +
"                            <td  colspan='5' mode='fill'>_</td>" + "\r\n" +
"                        </tr>" + "\r\n" +
"                        <tr>" + "\r\n" +
"                            <td colspan='4'>Total</td>" + "\r\n" +
"                            <td align='right'>70.00</td>" + "\r\n" +
"                        </tr>" + "\r\n" +
"                    </table>" + "\r\n" +
"                  </tml>";
		
		try{
			TextGenerator generator = new TextGenerator(30);
			String ouput = generator.GetTextTable(tml);
			System.out.println(ouput);
		}
		catch(TmsException e){
			e.printStackTrace();
		}
		
		try{
			TextGenerator generator = new TextGenerator(80);
			String ouput = generator.GetTextTable(tml);
			System.out.println(ouput);
		}
		catch(TmsException e){
			e.printStackTrace();
		}

		System.out.println("Done.");	
	}
}
