package com.plenusco.tml;

public abstract class SingleLineContentRenderingMode implements ContentRenderingMode
{
	private boolean rendered;
	private String content;

	public SingleLineContentRenderingMode(String content)
	{
		this.rendered = false;
		this.content = content;
		if (this.content == null)
		{
			this.content = "";
		}
	}
	public final FormatedLine GetLine(int width)
	{
		if (!rendered)
		{
			rendered = true;
			return new FormatedLine(GetLine(content, width), false);
		}
		else
		{
			return new FormatedLine("", false);
		}
	}

	protected abstract String GetLine(String content, int width);
}