package com.plenusco.tml;
import java.util.*;

public class Row
{
	private List<Cell> privateCells;
	public final List<Cell> getCells()
	{
		return privateCells;
	}
	
	public final void setCells(List<Cell> value)
	{
		privateCells = value;
	}
	
	private int privateRowSpan;
	public final int getRowSpan()
	{
		return privateRowSpan;
	}
	
	public final void setRowSpan(int value)
	{
		privateRowSpan = value;
	}

	public Row()
	{
		this(new ArrayList<Cell>());
	}

	public Row(List<Cell> cells)
	{
		this.setCells(cells);
	}
}