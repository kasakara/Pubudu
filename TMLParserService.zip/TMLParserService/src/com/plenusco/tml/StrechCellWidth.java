package com.plenusco.tml;

public class StrechCellWidth extends CellWidth
{
	@Override
	public int GetWidth(int fullWidth, String content)
	{
		return 0;
	}
}