package com.plenusco.tml;

public class WrapContentRenderingMode implements ContentRenderingMode
{
	private java.util.List<String> contentSegments;

	private int currentIndex = 0;

	public WrapContentRenderingMode(String content)
	{
		contentSegments = new java.util.ArrayList<String>();

		if (content == null)
		{
			return;
		}

		StringBuilder segmentBuilder = new StringBuilder();
		for (int i = 0; i < content.length(); i++){
		    char ch = content.charAt(i);        
			if (Character.isLetterOrDigit(ch) || ch == '.')
			{
				segmentBuilder.append(ch);
			}
			else
			{
				if (segmentBuilder.length() != 0)
				{
					contentSegments.add(segmentBuilder.toString());
					segmentBuilder = new StringBuilder();
				}

				contentSegments.add((new Character(ch)).toString());
			}
		}

		if (segmentBuilder.length() != 0)
		{
			contentSegments.add(segmentBuilder.toString());
		}
	}
	public final FormatedLine GetLine(int width)
	{
		StringBuilder outputBuilder = new StringBuilder();

		while ((currentIndex < contentSegments.size()) && (outputBuilder.length() + contentSegments.get(currentIndex).length() <= width))
		{
			outputBuilder.append(contentSegments.get(currentIndex));
			currentIndex++;
		}

		if (currentIndex < contentSegments.size())
		{
			if (outputBuilder.length() == 0)
			{
				//The current line segment is longer than the width. Need to split forcefully
				outputBuilder.append(contentSegments.get(currentIndex).substring(0, width));
				contentSegments.set(currentIndex, contentSegments.get(currentIndex).substring(width, contentSegments.get(currentIndex).length()));
			}

			return new FormatedLine(outputBuilder.toString().trim(), true);
		}
		else
		{
			return new FormatedLine(outputBuilder.toString().trim(), false);
		}
	}
}