package com.plenusco.tml;

public class FixedCellWidth extends CellWidth
{
	private int privateFixedWidth;
	public final int getFixedWidth()
	{
		return privateFixedWidth;
	}
	public final void setFixedWidth(int value)
	{
		privateFixedWidth = value;
	}

	public FixedCellWidth(int fixedWidth)
	{
		this.setFixedWidth(fixedWidth);
	}

	@Override
	public int GetWidth(int fullWidth, String content)
	{
		return getFixedWidth();
	}
}