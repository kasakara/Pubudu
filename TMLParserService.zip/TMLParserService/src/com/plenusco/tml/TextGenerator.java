package com.plenusco.tml;
import java.util.*;

public class TextGenerator
{
	private int privateFullWidth;
	public final int getFullWidth()
	{
		return privateFullWidth;
	}
	public final void setFullWidth(int value)
	{
		privateFullWidth = value;
	}

	public TextGenerator(int fullWidth)
	{
		this.setFullWidth(fullWidth);
	}

	public final String GetTextTable(String tmlText) throws TmsException
	{
		return GetText(TmlPhaser.pharse(tmlText));
	}

	public final String GetText(List<Table> tables)
	{
		StringBuilder textBuilder = new StringBuilder();

		for (Table table : tables)
		{
			if (table.getRows().size() == 0)
			{
				continue;
			}

			CalculateColumnWidths(table);
			BuildText(textBuilder, table);
		}

		return textBuilder.toString();
	}

	private static void BuildText(StringBuilder textBuilder, Table table)
	{
		for (Row row : table.getRows())
		{
			int cellCount = row.getCells().size();
			int[] widths = new int[cellCount];
			ContentRenderingMode[] renderingModes = new ContentRenderingMode[cellCount];

			int columnIndex = 0;
			for (int i = 0; i < row.getCells().size(); i++)
			{
				Cell cell = row.getCells().get(i);

				//Find total width of the cell 
				//(get sum of all columns if this cell spans multiple columns)
				widths[i] = 0;
				for (int span = 0; span < cell.getColSpan(); span++)
				{
					widths[i] += table.getColumns().get(columnIndex + span).getWidth();
				}

				renderingModes[i] = GetRenderMode(cell);

				columnIndex += cell.getColSpan();
			}

			boolean hasMoreLinesForAnyCell = true;
			while (hasMoreLinesForAnyCell)
			{
				hasMoreLinesForAnyCell = false;
				for (int i = 0; i < row.getCells().size(); i++)
				{
					Cell cell = row.getCells().get(i);
					FormatedLine line = renderingModes[i].GetLine(widths[i]);
					if (line.hasMoreLines())
					{
						hasMoreLinesForAnyCell = true;
					}

					FillContents(textBuilder, line.getContent(), widths[i], cell.getAlignment());
				}

				textBuilder.append("\r\n");
			}
		}
	}

	private static ContentRenderingMode GetRenderMode(Cell cell)
	{
		if (cell.getMode() == ContentRenderingModes.Trim)
		{
			return new TrimContentRenderingMode(cell.getContents());
		}
		else if (cell.getMode() == ContentRenderingModes.Wrap)
		{
			return new WrapContentRenderingMode(cell.getContents());
		}
		else if (cell.getMode() == ContentRenderingModes.Fill)
		{
			return new FillContentRenderingMode(cell.getContents());
		}
		else
		{
			throw new IllegalArgumentException("Invalid Render Mode");
		}
	}

	private static void FillContents(StringBuilder textBuilder, String content, int width, Alignment alignment)
	{
		if (content.length() > width)
		{
			textBuilder.append(content.substring(0, width));
		}
		else if (content.length() == width)
		{
			textBuilder.append(content);
		}
		else
		{
			AppendWithAlignment(textBuilder, content, width, alignment);
		}
	}

	private static void AppendWithAlignment(StringBuilder textBuilder, String content, int width, Alignment alignment)
	{
		int noOfSpacesRequired = width - content.length();

		if (alignment == Alignment.Left)
		{
			textBuilder.append(content);
			AppendRepeatedStrings(textBuilder, " ", noOfSpacesRequired);
		}
		else if (alignment == Alignment.Center)
		{
			int initialSpaces = noOfSpacesRequired / 2;
			AppendRepeatedStrings(textBuilder, " ", initialSpaces);
			textBuilder.append(content);
			AppendRepeatedStrings(textBuilder, " ", noOfSpacesRequired - initialSpaces);
		}
		else
		{
			AppendRepeatedStrings(textBuilder, " ", noOfSpacesRequired);
			textBuilder.append(content);
		}
	}
	
	public static void AppendRepeatedStrings(StringBuilder sb, String st, int n)
	{
		for (int i = 0; i < n; i++)
		{
			sb.append(st);
		}
	}

	private void CalculateColumnWidths(Table table)
	{
		//Add empty column objects
		for (Cell cell : table.getRows().get(0).getCells())
		{
			for (int i = 0; i < cell.getColSpan(); i++)
			{
				table.getColumns().add(new Column());
			}
		}

		//Assign the width of columns with pre-defined width calculation formula
		for (Row row : table.getRows())
		{
			int columnIndex = 0;

			for (Cell cell : row.getCells())
			{
				if (cell.getColSpan() > 1)
				{
					//Ignore cells that spans multiple columns
					columnIndex += cell.getColSpan();
					continue;
				}

				//find the max width of each column
				int cellWidth = cell.getCellWidth().GetWidth(this.getFullWidth(), cell.getContents());
				if (table.getColumns().get(columnIndex).getWidth() < cellWidth)
				{
					table.getColumns().get(columnIndex).setWidth(cellWidth);
				}

				columnIndex += 1;
			}
		}

		//calculate the width of remaining columns
		int totalAssignedWidth = 0;
		int noOfColumnsWithUnassignedWidth = 0;
		
		for(Column col: table.getColumns()){
			totalAssignedWidth +=  col.getWidth();
			if (col.getWidth() == 0){
				noOfColumnsWithUnassignedWidth++;
			}
		}

		if (getFullWidth() < totalAssignedWidth)
		{
			throw new IllegalArgumentException("Total width of each column is greter than the full width of the page");
		}
		
		if (noOfColumnsWithUnassignedWidth == 0)
		{
			return;
		}

		int unassignedColumnWidth = (this.getFullWidth() - totalAssignedWidth) / noOfColumnsWithUnassignedWidth;

		for (Column col : table.getColumns())
		{
			if (col.getWidth() == 0)
			{
				col.setWidth(unassignedColumnWidth);
			}
		}
	}
}
