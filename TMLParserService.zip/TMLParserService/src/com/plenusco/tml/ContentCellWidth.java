package com.plenusco.tml;

public class ContentCellWidth extends CellWidth
{
	@Override
	public int GetWidth(int fullWidth, String content)
	{
		return content.length() + 1;
	}
}