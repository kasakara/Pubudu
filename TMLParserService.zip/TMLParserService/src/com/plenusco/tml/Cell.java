package com.plenusco.tml;

public class Cell
{
	private String privateContents;
	public final String getContents()
	{
		return privateContents;
	}
	public final void setContents(String value)
	{
		privateContents = value;
	}
	private CellWidth privateCellWidth;
	public final CellWidth getCellWidth()
	{
		return privateCellWidth;
	}
	public final void setCellWidth(CellWidth value)
	{
		privateCellWidth = value;
	}

	private int privateColSpan;
	public final int getColSpan()
	{
		return privateColSpan;
	}
	public final void setColSpan(int value)
	{
		privateColSpan = value;
	}

	private ContentRenderingModes privateMode = ContentRenderingModes.Wrap;
	public final ContentRenderingModes getMode()
	{
		return privateMode;
	}
	
	public final void setMode(ContentRenderingModes value)
	{
		privateMode = value;
	}

	private Alignment privateAlignment = Alignment.Left;
	public final Alignment getAlignment()
	{
		return privateAlignment;
	}
	
	public final void setAlignment(Alignment value)
	{
		privateAlignment = value;
	}

	public Cell(String content)
	{
		this(content, new StrechCellWidth(), ContentRenderingModes.Trim, Alignment.Left, 1);

	}

	public Cell(String contents, CellWidth cellWidth, ContentRenderingModes renderingMode, Alignment alligment, int colSpan)
	{
		this.setContents(contents);
		this.setCellWidth(cellWidth);
		this.setColSpan(1);
		this.setMode(renderingMode);
		this.setAlignment(alligment);
		this.setColSpan(colSpan);
	}
}
