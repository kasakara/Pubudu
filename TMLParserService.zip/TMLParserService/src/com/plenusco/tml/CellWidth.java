package com.plenusco.tml;

public abstract class CellWidth
{
	public abstract int GetWidth(int fullWidth, String content);
}