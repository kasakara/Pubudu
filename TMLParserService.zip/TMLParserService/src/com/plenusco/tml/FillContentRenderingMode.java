package com.plenusco.tml;

public class FillContentRenderingMode extends SingleLineContentRenderingMode
{
	public FillContentRenderingMode(String contents)
	{
		super(contents);

	}

	@Override
	protected String GetLine(String content, int width)
	{
		StringBuilder outputBuilder = new StringBuilder();
		int size = content.length();
		for (int i = 0; i < width; i++)
		{
			outputBuilder.append(content.charAt(i % size));
		}
		return outputBuilder.toString();
	}
}