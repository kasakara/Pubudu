package com.plenusco.tml;

public class Column
{
	private int privateWidth;
	public final int getWidth()
	{
		return privateWidth;
	}
	public final void setWidth(int value)
	{
		privateWidth = value;
	}
}