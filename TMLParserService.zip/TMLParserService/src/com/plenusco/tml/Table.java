package com.plenusco.tml;
import java.util.*;

public class Table
{
	private List<Row> privateRows;
	public final List<Row> getRows()
	{
		return privateRows;
	}
	private void setRows(List<Row> value)
	{
		privateRows = value;
	}

	private List<Column> privateColumns;
	public final List<Column> getColumns()
	{
		return privateColumns;
	}
	private void setColumns(List<Column> value)
	{
		privateColumns = value;
	}

	public Table()
	{
		this(new ArrayList<Row>());

	}

	public Table(java.util.List<Row> rows)
	{
		this.setRows(rows);
		this.setColumns(new ArrayList<Column>());
	}
}