package com.plenusco.tml;

public interface ContentRenderingMode
{
	FormatedLine GetLine(int width);
}
