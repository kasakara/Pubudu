package com.plenusco.tml;

public class PercentageCellWidth extends CellWidth
{
	private double privatePercentage;
	public final double getPercentage()
	{
		return privatePercentage;
	}
	public final void setPercentage(double value)
	{
		privatePercentage = value;
	}

	public PercentageCellWidth(double percentage)
	{
		this.setPercentage(percentage);
	}

	@Override
	public int GetWidth(int fullWidth, String content)
	{
		return (int)(fullWidth * getPercentage());
	}
}