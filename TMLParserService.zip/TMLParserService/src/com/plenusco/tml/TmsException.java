package com.plenusco.tml;

public class TmsException extends Exception {
	private static final long serialVersionUID = 1L;

	public TmsException(String msg, Throwable cause) {
        super(msg, cause);
    }
}
