package com.plenusco.tml;

import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import java.io.IOException;
import java.io.StringReader;
import java.util.*;

public class TmlPhaser {
	public static List<Table> pharse(String tml) throws TmsException{
		List<Table> tableList = new ArrayList<Table>();
		
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = null;
		try {
		    builder = builderFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
		    throw new TmsException("Internal Error", e);  
		}
		
		try {
		    Document document = builder.parse(new InputSource(new StringReader(tml)));
		    
		    Element rootElement = document.getDocumentElement();		    
		    NodeList tableNodes = rootElement.getElementsByTagName("table");	    
		    for(int t=0; t<tableNodes.getLength(); t++){
		    	Element tableNode = (Element)tableNodes.item(t);
		    	Table table = new Table();
		    	
			    NodeList rowNodes = tableNode.getElementsByTagName("tr");	    	
			    for(int r=0; r<rowNodes.getLength(); r++){
			    	Element rowNode = (Element)rowNodes.item(r);
			    	Row row = new Row();
			    	
				    NodeList cellNodes = rowNode.getElementsByTagName("td");	    	
				    for(int c=0; c<cellNodes.getLength(); c++){
				    	Element cellNode = (Element)cellNodes.item(c);
				    	CellWidth width = GetCellWidth(cellNode);
				    	Alignment alignment = GetCellAlgiment(cellNode);
				    	ContentRenderingModes mode = GetContentRenderingMode(cellNode);
				    	int colspan = GetColSpan(cellNode);
				    	String content = cellNode.getTextContent();
				    	
				    	row.getCells().add(new Cell(content, width, mode, alignment, colspan));
				    }
			    	table.getRows().add(row);
			    }
		    	tableList.add(table);
		    }
		    
		} catch (SAXException e) {
			throw new TmsException("Invalid XML document format", e);  
		} catch (IOException e) {
			throw new TmsException("Invalid TML contents", e);  
		}
		
		return tableList;
	}
	
	private static int GetColSpan(Element cellElement)
	{
		String colSpanText = cellElement.getAttribute("colspan");
		
		if (colSpanText != null && colSpanText != ""){
			return Integer.parseInt(colSpanText);
		}

		return 1; //Return 1 as the default col span
	}
	
	private static Alignment GetCellAlgiment(Element cellElement)
	{
		String alignment = cellElement.getAttribute("align");
		
		if ("right".equals(alignment)){
			return Alignment.Right;
		}
		else if ("center".equals(alignment)){
			return Alignment.Center;
		}
		else{
			return Alignment.Left;
		}
	}
	
	private static ContentRenderingModes GetContentRenderingMode(Element cellElement)
	{
		String mode = cellElement.getAttribute("mode");
		
		if ("trim".equals(mode)){
			return ContentRenderingModes.Trim;
		}
		else if ("wrap".equals(mode)){
			return ContentRenderingModes.Wrap;
		}
		else if ("fill".equals(mode)){
			return ContentRenderingModes.Fill;
		}
		else{
			//Use wrap as the default render mode
			return ContentRenderingModes.Wrap;
		}
	}
	
	private static CellWidth GetCellWidth(Element cellElement)
	{
		String widthAttributeValue = cellElement.getAttribute("width");
		
		if (widthAttributeValue != null && widthAttributeValue != ""){
			if (widthAttributeValue.equals("*")){
				return new StrechCellWidth();
			}
			if (widthAttributeValue.endsWith("%")){
				double percentage = Double.parseDouble(widthAttributeValue.substring(0, widthAttributeValue.length() - 1));
				return new PercentageCellWidth(percentage / 100);
			}
			else{
				return new FixedCellWidth(Integer.parseInt(widthAttributeValue));
			}
		}
		else{
			return new ContentCellWidth();
		}
	}
}
