package com.plenusco.tml;

public class FormatedLine {
	
	private String content;
	public String getContent() {
		return content;
	}
	
	private boolean hasMoreLines;
	public boolean hasMoreLines() {
		return hasMoreLines;
	}
	
	public FormatedLine(String contents, boolean hasMoreLines){
		this.content = contents;
		this.hasMoreLines = hasMoreLines;
	}
}
