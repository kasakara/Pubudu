package com.plenusco.tml;

public class TrimContentRenderingMode extends SingleLineContentRenderingMode
{
	public TrimContentRenderingMode(String contents)
	{
		super(contents);
	}

	@Override
	protected String GetLine(String content, int width)
	{
		if (content.length() > width)
		{
			return content.substring(0, width);
		}
		else
		{
			return content;
		}
	}
}