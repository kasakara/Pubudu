package com.plenusco.tml;

public enum ContentRenderingModes
{
	None(0),
	Trim(1),
	Fill(2),
	Wrap(3);

	private int intValue;
	private static java.util.HashMap<Integer, ContentRenderingModes> mappings;
	private static java.util.HashMap<Integer, ContentRenderingModes> getMappings()
	{
		if (mappings == null)
		{
			synchronized (ContentRenderingModes.class)
			{
				if (mappings == null)
				{
					mappings = new java.util.HashMap<Integer, ContentRenderingModes>();
				}
			}
		}
		return mappings;
	}

	private ContentRenderingModes(int value)
	{
		intValue = value;
		getMappings().put(value, this);
	}

	public int getValue()
	{
		return intValue;
	}

	public static ContentRenderingModes forValue(int value)
	{
		return getMappings().get(value);
	}
}